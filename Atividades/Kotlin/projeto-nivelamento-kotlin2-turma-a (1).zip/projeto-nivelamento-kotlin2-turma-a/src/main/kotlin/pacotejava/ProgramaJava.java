package pacotejava;

import pacotekotlin.Atleta;
import pacotekotlin.Pais;

public class ProgramaJava {
    public static void main(String[] args) {
        //Pais pais0 = null;
        Pais pais1 = new Pais();

        //pais0.elogiar();

        Atleta a1 = new Atleta();
        a1.setNome("Zé Ruela");
        a1.setNome("aa");
        System.out.println(a1.getNome());


    }
}
