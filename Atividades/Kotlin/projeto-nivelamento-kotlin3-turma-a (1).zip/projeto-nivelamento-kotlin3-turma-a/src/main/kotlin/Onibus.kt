
class Onibus(val empresa:String, var destino:String, var passageiros:Int) {
}